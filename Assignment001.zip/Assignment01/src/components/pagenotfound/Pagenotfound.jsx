import React from 'react'
import './Pagenotfound.scss'

const Pagenotfound = () => {
  return (
    <div className='not-found-wrapper'>
        <h1>Page Not Found 😂</h1>
    </div>
  )
}

export default Pagenotfound